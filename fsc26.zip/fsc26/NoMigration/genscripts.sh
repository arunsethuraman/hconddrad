#!/bin/sh


for run in {1..112}
do
echo "cd t4; mkdir run"$run"; cd run"$run" ; cp ../t4.est . ; cp ../t4.tpl . ; cp ../t4*.obs . ;/home/tuf29140/work/fsc26_linux64/fsc26 -t t4.tpl -e t4.est -M0.001 -m -n200000 -N200000 -l40 -L40 -q -C10 -c3 -B6" >> torq2.txt
done
